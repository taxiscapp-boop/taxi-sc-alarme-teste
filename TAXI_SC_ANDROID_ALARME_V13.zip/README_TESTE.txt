TAXI-SC V2.1 - correção do fluxo de corrida

Alterações:
- corrida ativa fica persistida em taxiCorridaAtiva até o encerramento;
- corrida da agenda local passa para taxiCorridaAtiva e aguarda encerramento;
- espelho usa espelho_ao_vivo como fonte única para a corrida em andamento;
- corrida encerrada vai para taxiSC/Corridas do Dia;
- versionCode 12 / versionName 2.1;
- não foi incluído instalador/URL fictícia de atualização.

IMPORTANTE:
A atualização por cima do app instalado exige que o APK final seja assinado
com a mesma chave do APK atualmente instalado. Este pacote é o projeto-fonte.
