/* TAXI-SC SERVICE WORKER - offline + FCM + agenda local */
const CACHE_NAME = 'taxi-sc-app-v12-offline-2';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

importScripts('https://www.gstatic.com/firebasejs/12.18.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/12.18.0/firebase-messaging-compat.js');

const ICON = './icon-192.png';

firebase.initializeApp({
  apiKey: "AIzaSyBi9zHXL7wX25bg7xwkHkROH3hzaUbr48",
  authDomain: "taxi-sc-73fe5.firebaseapp.com",
  databaseURL: "https://taxi-sc-73fe5-default-rtdb.firebaseio.com",
  projectId: "taxi-sc-73fe5",
  storageBucket: "taxi-sc-73fe5.firebasestorage.app",
  messagingSenderId: "185690451927",
  appId: "1:185690451927:web:2d62b6f57d02e633396592"
});

const messaging = firebase.messaging();

/* ---------- OFFLINE APP SHELL ---------- */
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_SHELL))
      .catch(err => console.log('Cache offline parcial:', err))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;

  const url = new URL(event.request.url);

  /* Navegação: se a internet caiu, abre imediatamente a cópia local. */
  if (event.request.mode === 'navigate') {
    event.respondWith(
      caches.match('./index.html').then(cached => {
        if (cached) {
          /* Em segundo plano tenta atualizar a cópia para a próxima abertura. */
          fetch(event.request).then(response => {
            if (response && response.ok) {
              caches.open(CACHE_NAME).then(cache => cache.put('./index.html', response.clone())).catch(()=>{});
            }
          }).catch(()=>{});
          return cached;
        }
        return fetch(event.request);
      })
    );
    return;
  }

  /* Arquivos do próprio app: rede primeiro, cache como reserva. */
  if (url.origin === self.location.origin) {
    event.respondWith(
      fetch(event.request).then(response => {
        if (response && response.ok) {
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, response.clone())).catch(()=>{});
        }
        return response;
      }).catch(() => caches.match(event.request).then(r => r || caches.match('./index.html')))
    );
    return;
  }

  /*
     IMPORTANTE PARA O MODO OFFLINE:
     o index.html usa os módulos Firebase hospedados no gstatic.com.
     O navegador precisa conseguir carregar esses módulos mesmo sem internet.
     Quando houver internet, guardamos as respostas do gstatic no cache.
     Quando não houver, servimos a cópia já guardada.
  */
  if (url.hostname === 'www.gstatic.com' || url.hostname.endsWith('.gstatic.com')) {
    event.respondWith(
      fetch(event.request).then(response => {
        if (response && (response.ok || response.type === 'opaque')) {
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, response.clone())).catch(()=>{});
        }
        return response;
      }).catch(() => caches.match(event.request))
    );
  }
});

/* ---------- FIREBASE / FCM ---------- */
messaging.onBackgroundMessage((payload) => {
  const title = payload.notification?.title || payload.data?.titulo || '🚕 NOVA RESERVA!';
  const body = payload.notification?.body || payload.data?.corpo || '';
  const url = payload.data?.abrir === 'agendaOnline' ? './?abrir=agendaOnline' : './';
  self.registration.showNotification(title, {
    body,
    icon: ICON,
    badge: ICON,
    vibrate: [1000, 500, 1000],
    requireInteraction: true,
    data: { url }
  });
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  let url = e.notification.data?.url || './?abrir=agendaOnline';
  if (!url.startsWith('http')) url = new URL(url, self.location.origin).href;
  e.waitUntil(clients.matchAll({type:'window', includeUncontrolled:true}).then(w => {
    for (const c of w) {
      if (c.url.startsWith(self.location.origin)) return c.focus().then(() => c.navigate(url));
    }
    return clients.openWindow(url);
  }));
});

/* ---------- AGENDA LOCAL ----------
   Guarda os alarmes no armazenamento do Service Worker.
   Quando o navegador oferece Notification Triggers, usa agendamento nativo,
   que não depende de setInterval da página.
   Quando não oferece, mantém o fallback anterior com setTimeout.
*/
const ALARM_DB = 'taxi-sc-alarms-v1';
const ALARM_STORE = 'alarms';

function openAlarmDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(ALARM_DB, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(ALARM_STORE)) {
        db.createObjectStore(ALARM_STORE, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function saveAlarm(alarm) {
  const db = await openAlarmDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(ALARM_STORE, 'readwrite');
    tx.objectStore(ALARM_STORE).put(alarm);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function removeAlarm(id) {
  const db = await openAlarmDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(ALARM_STORE, 'readwrite');
    tx.objectStore(ALARM_STORE).delete(id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function getAlarms() {
  const db = await openAlarmDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(ALARM_STORE, 'readonly');
    const req = tx.objectStore(ALARM_STORE).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

async function showAlarm(alarm) {
  try {
    await self.registration.showNotification(alarm.titulo || 'TAXI-SC', {
      body: alarm.corpo || '',
      icon: ICON,
      badge: ICON,
      vibrate: [1000, 500, 1000, 500, 1000],
      requireInteraction: true,
      data: { url: './?abrir=agendaLocal' }
    });
  } finally {
    await removeAlarm(alarm.id);
  }
}

async function scheduleAlarm(alarm) {
  if (alarm.quando <= Date.now()) {
    await showAlarm(alarm);
    return;
  }

  /* Notification Triggers, se disponíveis no navegador. */
  if (typeof TimestampTrigger !== 'undefined' && 'showTrigger' in Notification.prototype) {
    try {
      await self.registration.showNotification(alarm.titulo || 'TAXI-SC', {
        body: alarm.corpo || '',
        icon: ICON,
        badge: ICON,
        vibrate: [1000, 500, 1000, 500, 1000],
        requireInteraction: true,
        showTrigger: new TimestampTrigger(alarm.quando),
        data: { url: './?abrir=agendaLocal' }
      });
      await removeAlarm(alarm.id);
      return;
    } catch (e) {
      console.log('Notification Trigger indisponível:', e);
    }
  }

  /* Fallback: mantém o comportamento anterior. */
  const delay = alarm.quando - Date.now();
  if (delay > 0 && delay < 2147483647) {
    setTimeout(() => showAlarm(alarm).catch(()=>{}), delay);
  }
}

async function checkDueAlarms() {
  const alarms = await getAlarms();
  const now = Date.now();
  for (const alarm of alarms) {
    if (alarm.quando <= now) await showAlarm(alarm);
  }
}

self.addEventListener('message', e => {
  if (!e.data) return;

  if (e.data.tipo === 'NOVA_RESERVA') {
    e.waitUntil(self.registration.showNotification(e.data.titulo || '🚕 NOVA RESERVA!', {
      body: e.data.corpo || '', icon: ICON, badge: ICON,
      vibrate:[1000,500,1000], requireInteraction:true,
      data:{url:'./?abrir=agendaOnline'}
    }));
  }

  if (e.data.tipo === 'AGENDAR_ALARME') {
    const quando = Number(e.data.quando);
    if (!Number.isFinite(quando)) return;

    const alarm = {
      id: String(e.data.id || ('alarm_' + quando + '_' + Math.random().toString(36).slice(2))),
      quando,
      titulo: e.data.titulo || 'TAXI-SC',
      corpo: e.data.corpo || ''
    };

    e.waitUntil(saveAlarm(alarm).then(() => scheduleAlarm(alarm)).catch(err => {
      console.log('erro agenda SW', err);
    }));
  }

  if (e.data.tipo === 'VERIFICAR_ALARMES') {
    e.waitUntil(checkDueAlarms().catch(()=>{}));
  }
});

/* Se o Service Worker for acordado por algum evento, entrega alarmes vencidos. */
self.addEventListener('sync', e => {
  if (e.tag === 'taxi-sc-alarmes') e.waitUntil(checkDueAlarms().catch(()=>{}));
});
