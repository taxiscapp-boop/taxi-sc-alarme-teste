package com.taxisc.teste;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Map;

public class BootReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context context, Intent intent){
    if(!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
    rescheduleSavedAlarms(context);
    OnlineReservationReceiver.scheduleNext(context);
  }

  private static void rescheduleSavedAlarms(Context context){
    AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
    if(am==null) return;
    if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) return;
    Map<String,?> all=context.getSharedPreferences("alarms",Context.MODE_PRIVATE).getAll();
    for(Map.Entry<String,?> e:all.entrySet()){
      String key=e.getKey();
      Object raw=e.getValue();
      if(!key.startsWith("active_") || !(raw instanceof String)) continue;
      String id=key.substring("active_".length());
      String[] p=((String)raw).split("\\t",-1);
      if(p.length<7) continue;
      long when;
      try{ when=Long.parseLong(p[0]); }catch(Exception ex){ continue; }
      if(when<=System.currentTimeMillis()) continue;
      Intent i=new Intent(context,AlarmReceiver.class)
          .putExtra("id",id)
          .putExtra("title",p[1])
          .putExtra("body",p[2])
          .putExtra("dataB",p[3])
          .putExtra("hora",p[4])
          .putExtra("nome",p[5])
          .putExtra("sound",p[6]);
      int req=Math.abs(id.hashCode());
      PendingIntent pi=PendingIntent.getBroadcast(context,req,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
      if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
      else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
    }
  }
}
