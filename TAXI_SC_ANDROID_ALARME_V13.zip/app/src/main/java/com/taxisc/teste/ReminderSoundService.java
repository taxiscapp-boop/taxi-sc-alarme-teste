package com.taxisc.teste;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.IBinder;
import androidx.annotation.Nullable;

public class ReminderSoundService extends Service {
    public static final String ACTION_START = "com.taxisc.teste.REMINDER_START";
    public static final String ACTION_STOP = "com.taxisc.teste.REMINDER_STOP";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_BODY = "body";
    public static final String EXTRA_SOUND = "sound";
    private static final int NOTIF_ID = 29001;
    private static final int STOP_REQ = 29002;
    private MediaPlayer player;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAlarm();
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_START.equals(intent.getAction())) {
            String title=intent.getStringExtra(EXTRA_TITLE);
            String body=intent.getStringExtra(EXTRA_BODY);
            String sound=intent.getStringExtra(EXTRA_SOUND);
            startAlarm(title, body, sound);
        }
        return START_NOT_STICKY;
    }

    private void startAlarm(String title, String body, String sound) {
        stopPlayerOnly();
        // Usa somente um toque de NOTIFICACAO escolhido pelo usuario e o repete continuamente.
        // Nunca usa som de despertador ou toque de chamada.
        startForeground(NOTIF_ID, buildNotification(title, body));

        try {
            String saved=getSharedPreferences("alarms",MODE_PRIVATE).getString("notification_sound_uri",null);
            android.net.Uri uri=saved!=null ? android.net.Uri.parse(saved) :
                    android.media.RingtoneManager.getActualDefaultRingtoneUri(this, android.media.RingtoneManager.TYPE_NOTIFICATION);
            if (uri == null) throw new IllegalStateException("Toque de notificacao nao encontrado");

            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            player.setDataSource(this, uri);
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception e) {
            stopPlayerOnly();
        }
    }

    private Notification buildNotification(String title, String body) {
        Intent stop = new Intent(this, ReminderStopReceiver.class);
        PendingIntent stopPi = PendingIntent.getBroadcast(this, STOP_REQ, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, MainActivity.REMINDER_CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.icon_192)
         .setContentTitle(title == null ? "LEMBRETE DE CORRIDA" : title)
         .setContentText(body == null ? "Toque ativo - toque na notificacao para parar" : body)
         .setContentIntent(stopPi)
         .setDeleteIntent(stopPi)
         .setOngoing(false)
         .setAutoCancel(true)
         .setShowWhen(true)
         .setPriority(Notification.PRIORITY_MAX)
         .addAction(new Notification.Action.Builder(null, "DESLIGAR LEMBRETE", stopPi).build());
        return b.build();
    }

    private void stopPlayerOnly() {
        try { if (player != null) { player.stop(); player.release(); } } catch (Exception ignored) {}
        player=null;
    }

    private void stopAlarm() {
        stopPlayerOnly();
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception e) { stopForeground(true); }
        stopSelf();
    }

    @Override public void onDestroy() { stopPlayerOnly(); super.onDestroy(); }
    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
