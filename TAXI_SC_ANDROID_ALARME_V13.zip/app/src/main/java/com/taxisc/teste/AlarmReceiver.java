package com.taxisc.teste;

import android.app.*;
import android.content.*;
import android.os.*;

public class AlarmReceiver extends BroadcastReceiver {
  public void onReceive(Context c, Intent i){
    String id=i.getStringExtra("id");
    if(id==null) return;
    // Bloqueia notificações órfãs: somente alarmes ainda registrados como ativos podem aparecer.
    if(id.startsWith("LEM_") || id.startsWith("HORA_")){
      if(!c.getSharedPreferences("alarms",Context.MODE_PRIVATE).contains("active_"+id)) return;
      c.getSharedPreferences("alarms",Context.MODE_PRIVATE).edit().remove("active_"+id).apply();
    }
    String t=i.getStringExtra("title"); String b=i.getStringExtra("body");
    Intent open=new Intent(c,MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
    open.putExtra("abrir","agendaLocal").putExtra("dataB",i.getStringExtra("dataB")).putExtra("hora",i.getStringExtra("hora")).putExtra("nome",i.getStringExtra("nome"));
    PendingIntent pi=PendingIntent.getActivity(c,Math.abs((id+".open").hashCode()),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
    Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,MainActivity.CHANNEL_ID):new Notification.Builder(c);
    nb.setSmallIcon(com.taxisc.teste.R.drawable.icon_192).setContentTitle(t).setContentText(b).setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH).setVibrate(new long[]{0,500,200,500,200,1000});
    nm.notify(Math.abs((id+".notif").hashCode()),nb.build());
  }
}
