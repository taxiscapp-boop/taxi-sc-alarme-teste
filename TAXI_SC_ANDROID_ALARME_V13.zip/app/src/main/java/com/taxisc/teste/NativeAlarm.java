package com.taxisc.teste;
import android.app.*;import android.content.*;import android.os.*;import android.provider.Settings;import android.net.Uri;import android.webkit.JavascriptInterface;
public class NativeAlarm {
 private final Context c; NativeAlarm(Context c){this.c=c.getApplicationContext();}
 @JavascriptInterface public void schedule(String id,long when,String title,String body){
  if(when<=System.currentTimeMillis()) return; AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  Intent i=new Intent(c,AlarmReceiver.class).putExtra("title",title).putExtra("body",body).putExtra("id",id);
  int rc=Math.abs(id.hashCode()); PendingIntent pi=PendingIntent.getBroadcast(c,rc,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) { try{c.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+c.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception ignored){} return; }
  if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
 }
 @JavascriptInterface public void cancel(String id){ AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); PendingIntent pi=PendingIntent.getBroadcast(c,Math.abs(id.hashCode()),new Intent(c,AlarmReceiver.class),PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE); if(pi!=null){am.cancel(pi);pi.cancel();} }
}
