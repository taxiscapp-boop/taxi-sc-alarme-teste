package com.taxisc.teste;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderStopReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Intent stop = new Intent(context, ReminderSoundService.class)
                .setAction(ReminderSoundService.ACTION_STOP);
        try {
            context.startService(stop);
        } catch (Exception ignored) {
            context.stopService(stop);
        }
    }
}
