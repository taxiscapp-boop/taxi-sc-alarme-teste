package com.taxisc.teste;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderStopReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Intent stop = new Intent(context, ReminderSoundService.class)
                .setAction(ReminderSoundService.ACTION_STOP);
        try {
            context.startService(stop);
        } catch (Exception ignored) {
            context.stopService(stop);
        }
        if (intent != null && intent.getBooleanExtra("abrirAgenda", false)) {
            Intent open = new Intent(context, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            open.putExtra("abrir", "agendaLocal")
                .putExtra("dataB", intent.getStringExtra("dataB"))
                .putExtra("hora", intent.getStringExtra("hora"))
                .putExtra("nome", intent.getStringExtra("nome"));
            context.startActivity(open);
        }
    }
}
