package com.taxisc.teste;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    static final String CHANNEL_ID = "taxi_agenda";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createChannel();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidAlarmBridge(this), "AndroidAlarm");
        webView.loadUrl("file:///android_asset/index.html");
        requestNotificationPermission();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
    }

    void requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))); }
                catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                Toast.makeText(this, "Ative 'Alarmes e lembretes' para o TAXI SC", Toast.LENGTH_LONG).show();
            }
        }
    }

    void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "Agenda Taxi", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Lembretes e horários de corridas");
            c.enableVibration(true);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    public static class AndroidAlarmBridge {
        final MainActivity a;
        AndroidAlarmBridge(MainActivity x) { a = x; }

        @JavascriptInterface public boolean scheduleAlarm(String id, long when, String title, String body) {
            if (when <= System.currentTimeMillis()) return false;
            AlarmManager am = (AlarmManager)a.getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                a.runOnUiThread(a::requestExactAlarmPermission);
                return false;
            }
            Intent i = new Intent(a, AlarmReceiver.class)
                    .putExtra("id", id).putExtra("title", title).putExtra("body", body);
            int request = Math.abs(id.hashCode());
            android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(
                    a, request, i,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
            return true;
        }

        @JavascriptInterface public void cancelAlarm(String id) {
            Intent i = new Intent(a, AlarmReceiver.class);
            int request = Math.abs(id.hashCode());
            android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(
                    a, request, i,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
            ((AlarmManager)a.getSystemService(Context.ALARM_SERVICE)).cancel(pi);
        }
    }
}
