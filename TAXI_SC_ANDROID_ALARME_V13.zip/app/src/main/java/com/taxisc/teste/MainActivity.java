package com.taxisc.teste;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.text.TextUtils;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView webView;
    static final String CHANNEL_ID = "taxi_agenda";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        createChannel();
        webView=new WebView(this);
        setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView,true);
        webView.setWebChromeClient(new WebChromeClient());
        final WebViewAssetLoader loader=new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){ return loader.shouldInterceptRequest(r.getUrl()); }
            @Override @SuppressWarnings("deprecation") public WebResourceResponse shouldInterceptRequest(WebView v,String u){ return loader.shouldInterceptRequest(Uri.parse(u)); }
        });
        webView.addJavascriptInterface(new AndroidAlarmBridge(this), "AndroidAlarm");
        webView.loadUrl(buildStartUrl(getIntent()));
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);
    }

    private String buildStartUrl(Intent intent){
        String base="https://appassets.androidplatform.net/assets/index.html";
        if(intent!=null && "agendaLocal".equals(intent.getStringExtra("abrir"))){
            String dataB=intent.getStringExtra("dataB"); String hora=intent.getStringExtra("hora"); String nome=intent.getStringExtra("nome");
            return base+"?abrir=agendaLocal&dataB="+Uri.encode(dataB==null?"":dataB)+"&hora="+Uri.encode(hora==null?"":hora)+"&nome="+Uri.encode(nome==null?"":nome);
        }
        if(intent!=null && "agendaOnline".equals(intent.getStringExtra("abrir"))) return base+"?abrir=agendaOnline";
        return base;
    }

    @Override protected void onNewIntent(Intent intent){ super.onNewIntent(intent); setIntent(intent); if(webView!=null) webView.loadUrl(buildStartUrl(intent)); }

    void requestExactAlarmPermission(){
        if(Build.VERSION.SDK_INT>=31){
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            if(!am.canScheduleExactAlarms()){
                try{ startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()))); }
                catch(Exception e){ startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                Toast.makeText(this,"Ative 'Alarmes e lembretes' para o TAXI SC",Toast.LENGTH_LONG).show();
            }
        }
    }

    void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL_ID,"Agenda Taxi",NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Lembretes e horários de corridas");
            c.enableVibration(true);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    public static class AndroidAlarmBridge {
        final MainActivity a;
        AndroidAlarmBridge(MainActivity x){a=x;}
        @JavascriptInterface public boolean scheduleAlarm(String id,long when,String title,String body,String dataB,String hora,String nome){
            if(when<=System.currentTimeMillis()) return false;
            AlarmManager am=(AlarmManager)a.getSystemService(ALARM_SERVICE);
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){
                a.runOnUiThread(a::requestExactAlarmPermission);
                return false;
            }
            Intent i=new Intent(a,AlarmReceiver.class).putExtra("id",id).putExtra("title",title).putExtra("body",body).putExtra("dataB",dataB).putExtra("hora",hora).putExtra("nome",nome);
            int req=Math.abs(id.hashCode());
            PendingIntent pi=PendingIntent.getBroadcast(a,req,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
            else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
            return true;
        }
        @JavascriptInterface public void cancelAlarm(String id){
            Intent i=new Intent(a,AlarmReceiver.class);
            int req=Math.abs(id.hashCode());
            PendingIntent pi=PendingIntent.getBroadcast(a,req,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            ((AlarmManager)a.getSystemService(ALARM_SERVICE)).cancel(pi);
        }
    }
}
