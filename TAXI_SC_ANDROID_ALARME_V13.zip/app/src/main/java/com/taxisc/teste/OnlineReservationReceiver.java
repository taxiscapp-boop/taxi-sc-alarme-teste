package com.taxisc.teste;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class OnlineReservationReceiver extends BroadcastReceiver {
  public static final int REQUEST_CODE=91827;
  private static final String DB="https://taxi-sc-73fe5-default-rtdb.firebaseio.com/taxi_sc/5549991539549/reservas.json";

  @Override public void onReceive(Context c, Intent i){
    scheduleNext(c);
    new Thread(() -> check(c)).start();
  }

  static void scheduleNext(Context c){
    AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
    Intent i=new Intent(c,OnlineReservationReceiver.class);
    PendingIntent pi=PendingIntent.getBroadcast(c,REQUEST_CODE,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    long when=System.currentTimeMillis()+120000L;
    if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) return;
    // AlarmClock é o modo de alarme mais resistente ao Doze para esta verificação
    // periódica. setExactAndAllowWhileIdle pode ser limitado quando o aparelho fica
    // muito tempo em sono profundo (há uma cota entre alarmes durante o idle).
    // O aplicativo usa este alarme somente para acordar e verificar uma nova reserva.
    if(Build.VERSION.SDK_INT>=21){
      Intent show=new Intent(c,MainActivity.class);
      show.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
      PendingIntent showPi=PendingIntent.getActivity(c,REQUEST_CODE+1,show,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
      AlarmManager.AlarmClockInfo info=new AlarmManager.AlarmClockInfo(when,showPi);
      am.setAlarmClock(info,pi);
    } else {
      am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
    }
  }

  static String get(String url) throws Exception{
    HttpURLConnection con=(HttpURLConnection)new URL(url).openConnection();
    con.setConnectTimeout(7000); con.setReadTimeout(7000); con.setRequestMethod("GET");
    InputStream in=(con.getResponseCode()>=400?con.getErrorStream():con.getInputStream());
    if(in==null) return "null";
    BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8")); StringBuilder s=new StringBuilder(); String line;
    while((line=br.readLine())!=null)s.append(line); br.close(); con.disconnect(); return s.toString();
  }

  static void check(Context c){
    try{
      String json=get(DB); if(json==null || json.equals("null")) return;
      JSONObject root=new JSONObject(json);
      SharedPreferences sp=c.getSharedPreferences("online_notify",Context.MODE_PRIVATE);
      Set<String> pendingNow=new HashSet<>();
      Iterator<String> days=root.keys();
      while(days.hasNext()){
        String day=days.next(); JSONObject dayObj=root.optJSONObject(day); if(dayObj==null) continue;
        Iterator<String> keys=dayObj.keys();
        while(keys.hasNext()){
          String key=keys.next(); JSONObject r=dayObj.optJSONObject(key); if(r==null) continue;
          String status=r.optString("status", "pendente");
          if(!"pendente".equals(status)) continue;
          String nome=r.optString("nome","Cliente"); String hora=r.optString("horario","");
          String id=day+"__"+key; pendingNow.add(id);
          if(!sp.getBoolean("notified_"+id,false)){
            notifyNow(c,id,"🚕 NOVA RESERVA!",nome+" - "+hora);
          }
        }
      }
      // Remove old markers for reservations that no longer exist/pending, keeping the store small.
      Map<String,?> all=sp.getAll(); SharedPreferences.Editor ed=sp.edit();
      for(String k:all.keySet()) if(k.startsWith("notified_") && !pendingNow.contains(k.substring(9))) ed.remove(k);
      ed.apply();
    }catch(Exception ignored){}
  }

  static void notifyNow(Context c,String id,String title,String body){
    SharedPreferences sp=c.getSharedPreferences("online_notify",Context.MODE_PRIVATE);
    if(sp.getBoolean("notified_"+id,false)) return;
    sp.edit().putBoolean("notified_"+id,true).apply();
    Intent open=new Intent(c,MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP); open.putExtra("abrir","agendaOnline");
    PendingIntent pi=PendingIntent.getActivity(c,Math.abs((id+".online.open").hashCode()),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
    Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,MainActivity.ONLINE_CHANNEL_ID):new Notification.Builder(c);
    nb.setSmallIcon(com.taxisc.teste.R.drawable.icon_192).setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH).setVibrate(new long[]{0,500,200,500,200,1000});
    nm.notify(Math.abs((id+".online.notif").hashCode()),nb.build());
  }

  static void cancelNotification(Context c,String id){
    c.getSharedPreferences("online_notify",Context.MODE_PRIVATE).edit().remove("notified_"+id).apply();
    NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
    nm.cancel(Math.abs((id+".online.notif").hashCode()));
  }
}
