TAXI-SC V13 - PACOTE PWA PARA IPHONE

O que foi feito:
- Mantidos os arquivos e a lógica original do TAXI-SC.
- Criada uma cópia web em ios-pwa/ para instalação pela tela inicial do iPhone.
- Adicionados metadados Apple para instalação como app web e ícone da tela inicial.
- Adaptação mínima de área segura (notch/indicador inferior).
- Android original preservado integralmente na pasta android-original/.

INSTALAÇÃO NO IPHONE 15
1. Publique TODO o conteúdo da pasta ios-pwa/ em um endereço HTTPS (por exemplo, no seu site Cloudflare Pages).
2. No iPhone, abra esse endereço pelo Safari (não pelo Chrome).
3. Toque em Compartilhar > Adicionar à Tela de Início > Adicionar.
4. Abra o TAXI-SC pelo ícone criado na tela inicial.

LIMITAÇÕES IMPORTANTES DO iOS
- Este pacote cria uma versão PWA instalável; não é um arquivo IPA/App Store.
- O código Android nativo (AlarmManager, integração Android e receivers) não existe no iOS.
- O fallback atual de alarmes usa temporizadores do Service Worker e NÃO garante lembretes locais com o app fechado/suspenso no iPhone.
- Notificações push no iOS exigem PWA adicionada à Tela de Início, permissão do usuário e configuração/registro Web Push (incluindo chave VAPID). O projeto recebido não contém chamada getToken/VAPID na página, portanto isso ainda precisa ser configurado e testado.
- A primeira abertura requer internet para conectar ao Firebase.

IMPORTANTE: os arquivos em android-original/ são cópia do ZIP recebido, sem alterações. Este pacote não substitui nem altera o APK Android.
