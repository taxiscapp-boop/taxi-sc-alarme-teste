package com.taxisc.teste;

import android.Manifest;import android.app.*;import android.content.*;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.webkit.*;import android.view.*;import java.util.*;

public class MainActivity extends Activity {
    WebView web; static final int NOTIF=100;
    @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); web.setBackgroundColor(0xFFF3F3F3); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true); web.getSettings().setAllowContentAccess(true); web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new NativeAlarm(this),"AndroidAlarm"); setContentView(web); web.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=0) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF);
        if(Build.VERSION.SDK_INT>=31){ try{ AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(!am.canScheduleExactAlarms()){ startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()))); } }catch(Exception ignored){} }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
