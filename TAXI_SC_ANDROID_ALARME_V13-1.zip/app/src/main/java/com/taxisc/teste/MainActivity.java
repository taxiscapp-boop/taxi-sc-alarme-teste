package com.taxisc.teste;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private WebView webView;
    static final String CHANNEL_ID = "taxi_agenda";
    static final String ONLINE_CHANNEL_ID = "taxi_online";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        createChannel();
        webView=new WebView(this);
        setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView,true);
        webView.setWebChromeClient(new WebChromeClient());
        final WebViewAssetLoader loader=new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/assets_v13/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
                Uri u=r.getUrl();
                if(u!=null && ("http".equalsIgnoreCase(u.getScheme()) || "https".equalsIgnoreCase(u.getScheme())) &&
                   !"appassets.androidplatform.net".equalsIgnoreCase(u.getHost())){
                    try{ startActivity(new Intent(Intent.ACTION_VIEW,u)); }catch(Exception ignored){}
                    return true;
                }
                return false;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){ return loader.shouldInterceptRequest(r.getUrl()); }
            @Override @SuppressWarnings("deprecation") public WebResourceResponse shouldInterceptRequest(WebView v,String u){ return loader.shouldInterceptRequest(Uri.parse(u)); }
        });
        webView.addJavascriptInterface(new AndroidAlarmBridge(this), "AndroidAlarm");
        webView.loadUrl(buildStartUrl(getIntent()));
        scheduleOnlinePoll();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);
    }

    private String buildStartUrl(Intent intent){
        String base="https://appassets.androidplatform.net/assets_v13/index.html";
        if(intent!=null && "agendaLocal".equals(intent.getStringExtra("abrir"))){
            String dataB=intent.getStringExtra("dataB"); String hora=intent.getStringExtra("hora"); String nome=intent.getStringExtra("nome");
            return base+"?abrir=agendaLocal&dataB="+Uri.encode(dataB==null?"":dataB)+"&hora="+Uri.encode(hora==null?"":hora)+"&nome="+Uri.encode(nome==null?"":nome);
        }
        if(intent!=null && "agendaOnline".equals(intent.getStringExtra("abrir"))) return base+"?abrir=agendaOnline";
        return base;
    }

    @Override protected void onNewIntent(Intent intent){ super.onNewIntent(intent); setIntent(intent); if(webView!=null) webView.loadUrl(buildStartUrl(intent)); }

    void requestExactAlarmPermission(){
        if(Build.VERSION.SDK_INT>=31){
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            if(!am.canScheduleExactAlarms()){
                try{ startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()))); }
                catch(Exception e){ startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                Toast.makeText(this,"Ative 'Alarmes e lembretes' para o TAXI SC",Toast.LENGTH_LONG).show();
            }
        }
    }

    void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL_ID,"Agenda Taxi",NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Lembretes e horários de corridas"); c.enableVibration(true);
            NotificationChannel o=new NotificationChannel(ONLINE_CHANNEL_ID,"Novos agendamentos on-line",NotificationManager.IMPORTANCE_HIGH);
            o.setDescription("Avisos de novos agendamentos feitos pelos clientes"); o.enableVibration(true);
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(c); nm.createNotificationChannel(o);
        }
    }

    void scheduleOnlinePoll(){
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        Intent i=new Intent(this,OnlineReservationReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(this,OnlineReservationReceiver.REQUEST_CODE,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        long when=System.currentTimeMillis()+120000L;
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) return;
        if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
    }

    public static class AndroidAlarmBridge {
        final MainActivity a;
        AndroidAlarmBridge(MainActivity x){a=x;}
        @JavascriptInterface public boolean scheduleAlarm(String id,long when,String title,String body,String dataB,String hora,String nome){
            if(when<=System.currentTimeMillis()) return false;
            AlarmManager am=(AlarmManager)a.getSystemService(ALARM_SERVICE);
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){
                a.runOnUiThread(a::requestExactAlarmPermission); return false;
            }
            Intent i=new Intent(a,AlarmReceiver.class).putExtra("id",id).putExtra("title",title).putExtra("body",body).putExtra("dataB",dataB).putExtra("hora",hora).putExtra("nome",nome);
            int req=Math.abs(id.hashCode());
            PendingIntent pi=PendingIntent.getBroadcast(a,req,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
            a.getSharedPreferences("alarms",MODE_PRIVATE).edit().putString("active_"+id,title+"\n"+body).apply();
            return true;
        }
        @JavascriptInterface public void cancelAlarm(String id){
            Intent i=new Intent(a,AlarmReceiver.class); int req=Math.abs(id.hashCode());
            PendingIntent pi=PendingIntent.getBroadcast(a,req,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            ((AlarmManager)a.getSystemService(ALARM_SERVICE)).cancel(pi);
            a.getSharedPreferences("alarms",MODE_PRIVATE).edit().remove("active_"+id).apply();
        }
        @JavascriptInterface public void notifyOnlineReservation(String id,String title,String body){ OnlineReservationReceiver.notifyNow(a,id,title,body); }
        @JavascriptInterface public void cancelOnlineNotification(String id){ OnlineReservationReceiver.cancelNotification(a,id); }
        @JavascriptInterface public void openWhatsApp(String phone,String text){
            try{
                String digits = phone==null ? "" : phone.replaceAll("\\D", "");
                if(!digits.startsWith("55") && digits.length()>0) digits="55"+digits;
                Uri appUri=Uri.parse("whatsapp://send?phone="+digits+"&text="+Uri.encode(text==null?"":text));
                Intent appIntent=new Intent(Intent.ACTION_VIEW,appUri);
                try{ a.startActivity(appIntent); return; }catch(Exception ignored){}
                Uri webUri=Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(text==null?"":text));
                a.startActivity(new Intent(Intent.ACTION_VIEW,webUri));
            }catch(Exception e){ Toast.makeText(a,"Não foi possível abrir o WhatsApp",Toast.LENGTH_SHORT).show(); }
        }

        @JavascriptInterface public boolean saveReceipt(String base64,String fileName){
            try{
                byte[] data=Base64.decode(base64,Base64.DEFAULT);
                if(Build.VERSION.SDK_INT>=29){
                    ContentValues v=new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, safeName(fileName));
                    v.put(MediaStore.Downloads.MIME_TYPE,"image/png");
                    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/TAXI-SC");
                    v.put(MediaStore.Downloads.IS_PENDING,1);
                    Uri uri=a.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(uri==null) return false;
                    try(OutputStream out=a.getContentResolver().openOutputStream(uri)){ if(out==null) throw new IOException(); out.write(data); }
                    v.clear(); v.put(MediaStore.Downloads.IS_PENDING,0); a.getContentResolver().update(uri,v,null,null);
                    return true;
                }
                return false;
            }catch(Exception e){ return false; }
        }

        @JavascriptInterface public boolean shareReceipt(String base64,String fileName){
            try{
                byte[] data=Base64.decode(base64,Base64.DEFAULT);
                File dir=new File(a.getCacheDir(),"receipts"); if(!dir.exists() && !dir.mkdirs()) return false;
                File f=new File(dir,safeName(fileName));
                try(FileOutputStream out=new FileOutputStream(f)){out.write(data);}
                Uri uri=FileProvider.getUriForFile(a,a.getPackageName()+".fileprovider",f);
                Intent send=new Intent(Intent.ACTION_SEND); send.setType("image/png"); send.putExtra(Intent.EXTRA_STREAM,uri); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                send.setClipData(ClipData.newRawUri("Recibo",uri));
                try{send.setPackage("com.whatsapp"); a.startActivity(send);}catch(Exception e){
                    send.setPackage(null); a.startActivity(Intent.createChooser(send,"Enviar recibo"));
                }
                return true;
            }catch(Exception e){ a.runOnUiThread(()->Toast.makeText(a,"Não foi possível enviar o recibo",Toast.LENGTH_SHORT).show()); return false; }
        }

        private static String safeName(String n){
            String x=(n==null||n.trim().isEmpty())?"recibo.png":n.replaceAll("[^a-zA-Z0-9._-]","_");
            return x.toLowerCase().endsWith(".png")?x:x+".png";
        }
    }
}
